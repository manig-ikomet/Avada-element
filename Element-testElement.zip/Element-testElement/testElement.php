<?php
$section_title = isset($atts['section_title'])?$atts['section_title']:"";
$link_selector = isset($atts['link_selector'])?$atts['link_selector']:"";
// print_r($content);

?>

<main class="clearfix width-100 homeSlider">
  <section class="fusion-fullwidth fullwidth-box fusion-parallax-none nonhundred-percent-fullwidth non-hundred-percent-height-scrolling">
      <div class="content-wrapper">
            <div class="fusion-builder-rows fusion-rows ">

                <h1><?php echo $section_title;  ?></h1>
                <?php echo $content;  ?>
                <a href="<?php echo $link_selector; ?>">Learn More</a>
            </div>
          </div>
       
  </section>
</main>
