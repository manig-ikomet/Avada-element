<?php
/**
 * Plugin Name: Addon - TestElement
 * Plugin URI: 
 * Description: ...
 * Version: 1.1
 * Author: 
 * Author URI: 
 *
 * @package Addon - TestElement
 */

// Plugin Folder Path.
if ( ! defined( 'testElement_ADDON_PLUGIN_DIR' ) ) {
	define( 'testElement_ADDON_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
}

register_activation_hook( __FILE__, array( 'testElementAddonFB', 'testElementAddonFB_activation' ) );

if ( ! class_exists( 'testElementAddonFB' ) ) {

	/**
	 * The main plugin class.
	 */
	class testElementAddonFB {

		/**
		 * The one, true instance of this object.
		 *
		 * @static
		 * @access private
		 * @since 1.0
		 * @var object
		 */
		private static $instance;

		/**
		 * Creates or returns an instance of this class.
		 *
		 * @static
		 * @access public
		 * @since 1.0
		 */
		public static function get_instance() {

			// If an instance hasn't been created and set to $instance create an instance and set it to $instance.
			if ( null === self::$instance ) {
				self::$instance = new testElementAddonFB();
			}
			return self::$instance;
		}

		/**
		 * Constructor.
		 *
		 * @since 1.0
		 */
		public function __construct() {
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
			add_shortcode( 'testElement_parent', array( $this, 'testElement_parent' ) );
		}

		/**
		 * Enqueue scripts & styles.
		 *
		 * @access public
		 * @since 1.0
		 */
		public function enqueue_scripts() {
			//wp_enqueue_style( 'testElement', plugins_url( 'css/testElement.css', __FILE__ ) );
			//wp_enqueue_script( 'lazy-load', plugins_url( 'js/jquery.lazy-load-google-maps.min.js', __FILE__ ), array('jquery'));
			//wp_enqueue_script( 'testElement-Script', plugins_url( 'js/location-land.js', __FILE__ ), array('jquery'));
			//wp_enqueue_script( 'testElement-map',  'https://maps.googleapis.com/maps/api/js?key=AIzaSyAl_pnmDDhpTCew_iE21XNi6Qd1pqL9I30&callback=initMap', array('jquery'));

 		}

		/**
		 * Returns the content.
		 *
		 * @access public
		 * @since 1.0
		 * @param array  $atts    The attributes array.
		 * @param string $content The content.
		 * @return string
		 */
		public function testElement_parent( $atts, $content ) {

		
			$post_per_page=-1;
			ob_start();
			// print_r($atts);
			// $atts['content'] = $content;
			// echo $atts['content']."test </br>";
			// print_r($atts);

			// echo "content". ;

			include "testElement.php";

              $output = ob_get_contents();
			  ob_end_clean();
			return $output;
		}

		/**
		 * Processes that must run when the plugin is activated.
		 *
		 * @static
		 * @access public
		 * @since 1.0
		*/
		public static function testElementAddonFB_activation() {
			if ( ! class_exists( 'FusionBuilder' ) ) {
				echo '<style type="text/css">#error-page > p{display:-webkit-flex;display:flex;}#error-page img {height: 120px;margin-right:25px;}.fb-heading{font-size: 1.17em; font-weight: bold; display: block; margin-bottom: 15px;}.fb-link{display: inline-block;margin-top:15px;}.fb-link:focus{outline:none;box-shadow:none;}</style>';
				$message = '<span class="fb-heading">Core Partners Addon could not be activated</span>';
				wp_die( wp_kses_post( $message ) );
			}
		}
	}

	/**
	 * Instantiate testElementAddonFB class.
	 */
	function testElement_addon_activate() {
		testElementAddonFB::get_instance();
	}

	add_action( 'wp_loaded', 'testElement_addon_activate', 10 );
}

/**
 * Map shortcode to Fusion Builder.
 *
 * @since 1.0
 */
function map_testElement_addon_with_fb() {
	

	// Map settings for parent shortcode.
	fusion_builder_map(
		array(
			'name'          => esc_attr__( 'Addon - Test Element', 'fusion-builder' ),
			'shortcode'     => 'testElement_parent',
			'icon'          => 'fa fa-users',
			'preview_id'    => 'fusion-builder-block-module-sample-addon-preview-template',
			'params'        => array(
				array(
					'type'=> 'textfield',
					  	'heading'     => esc_attr__( 'Title', 'fusion-builder' ),
						'description' => esc_attr__( 'Heading for Section', 'fusion-builder' ),
						'param_name'  => 'section_title',
						'value'       => ''
				),		
				array(
	                'type'        => 'tinymce',
	                'heading'     => esc_attr__( 'Content', 'fusion-builder' ),
	                'description' => esc_attr__( 'Enter content for this section.', 'fusion-builder' ),
	                'param_name'  => 'element_content',
	                'value'       => esc_attr__( '', 'fusion-builder' ),
				),
				array(
					'type'        => 'link_selector',
					'heading'     => esc_attr__( 'Link', 'fusion-builder' ),
					'description' => esc_attr__( 'Add a short description for the field.', 'fusion-builder' ),
					'param_name'  => 'url',
					'value'       => '',

				  )
			),
		)
	);
}

add_action( 'fusion_builder_before_init', 'map_testElement_addon_with_fb', 11 );
